function [merge_pairs, wcc] = getPotentialMerge(folder_data, userSettings)
%GETPOTENTIALMERGES Find candidate cluster pairs for merging (Kilosort 4).
%
% A pair is returned only when neither cluster is labelled noise, the two
% clusters have the same peak channel, TAD/TLD/ZCI/PAD/HWI are below their
% thresholds, and WCC is above its threshold.
%
% Required fields in userSettings.merging:
%   waveform_window
%   trough_amplitude_difference
%   trough_latency_difference
%   zero_crossings_interval
%   peak_amplitude_difference
%   half_width_interval
%   waveform_cross_correlation
%   verbose
%
% All spikes whose waveform window lies inside temp_wh.dat are used for
% each cluster's mean waveform.

narginchk(2, 2);

folder_data = char(folder_data);
merging = userSettings.merging;
required_fields = { ...
    'waveform_window', ...
    'trough_amplitude_difference', ...
    'trough_latency_difference', ...
    'zero_crossings_interval', ...
    'peak_amplitude_difference', ...
    'half_width_interval', ...
    'waveform_cross_correlation'};
for i = 1:numel(required_fields)
    if ~isfield(merging, required_fields{i})
        error('getPotentialMerges:MissingSetting', ...
            'Missing userSettings.merging.%s.', required_fields{i});
    end
end

waveform_window = double(merging.waveform_window(:).');
if numel(waveform_window) ~= 2 || any(~isfinite(waveform_window)) || ...
        any(waveform_window ~= fix(waveform_window)) || ...
        waveform_window(1) > waveform_window(2)
    error('getPotentialMerges:InvalidWindow', ...
        'merging.waveform_window must contain two increasing integers.');
end
n_samples = diff(waveform_window) + 1;

thresholds = double([ ...
    merging.trough_amplitude_difference, ...
    merging.trough_latency_difference, ...
    merging.zero_crossings_interval, ...
    merging.peak_amplitude_difference, ...
    merging.half_width_interval]);
if numel(thresholds) ~= 5 || any(~isfinite(thresholds)) || any(thresholds < 0)
    error('getPotentialMerges:InvalidThreshold', ...
        'TAD/TLD/ZCI/PAD/HWI thresholds must be finite and nonnegative.');
end
wcc_threshold = double(merging.waveform_cross_correlation);
if ~isscalar(wcc_threshold) || ~isfinite(wcc_threshold) || ...
        wcc_threshold < -1 || wcc_threshold > 1
    error('getPotentialMerges:InvalidWCCThreshold', ...
        'WCC threshold must be a scalar between -1 and 1.');
end

if isfield(merging, 'verbose')
    verbose = logical(merging.verbose);
else
    verbose = false;
end

if isfield(merging, 'uV_per_bit')
    uV_per_bit = double(merging.uV_per_bit);
elseif isfield(userSettings, 'removeNoiseInsideCluster') && ...
        isfield(userSettings.removeNoiseInsideCluster, 'uV_per_bit')
    
uV_per_bit = double(userSettings.removeNoiseInsideCluster.uV_per_bit);
else
    error('getPotentialMerges:MissinguVScale', ...
        ['Set userSettings.merging.uV_per_bit or ', ...
         'userSettings.removeNoiseInsideCluster.uV_per_bit.']);
end
validateattributes(uV_per_bit, {'numeric'}, ...
    {'scalar', 'real', 'positive', 'finite'}, mfilename, 'uV_per_bit');

%% Load Kilosort 4 output
spike_times = double(readNPY(fullfile(folder_data, 'spike_times.npy')));
spike_clusters = double(readNPY(fullfile(folder_data, 'spike_clusters.npy')));
spike_times = spike_times(:);
spike_clusters = spike_clusters(:);
if numel(spike_times) ~= numel(spike_clusters)
    error('getPotentialMerges:SpikeArraySizeMismatch', ...
        'spike_times.npy and spike_clusters.npy have different lengths.');
end

channel_map = double(readNPY(fullfile(folder_data, 'channel_map.npy')));
channel_map = channel_map(:);       % zero-based binary-channel IDs
channel_rows = channel_map + 1;     % one-based MATLAB rows
whitening_mat_inv = double(readNPY( ...
    fullfile(folder_data, 'whitening_mat_inv.npy')));
n_active_channels = numel(channel_rows);
if ~isequal(size(whitening_mat_inv), ...
        [n_active_channels, n_active_channels])
    error('getPotentialMerges:WhiteningSizeMismatch', ...
        ['whitening_mat_inv.npy is %d-by-%d, but channel_map.npy contains ', ...
         '%d channels.'], size(whitening_mat_inv, 1), ...
        size(whitening_mat_inv, 2), n_active_channels);
end

n_channels = double(getKilosortNChannels(folder_data));
validateattributes(n_channels, {'numeric'}, ...
    {'scalar', 'integer', 'positive'}, mfilename, 'n_channels');
if any(channel_rows < 1 | channel_rows > n_channels)
    error('getPotentialMerges:InvalidChannelMap', ...
        'channel_map.npy contains an index outside temp_wh.dat range.');
end

path_data = fullfile(folder_data, 'temp_wh.dat');
if ~isfile(path_data)
    error('getPotentialMerges:MissingTempWh', ...
        'Cannot find the Kilosort 4 preprocessed file temp_wh.dat.');
end
file_info = dir(path_data);
bytes_per_sample = 2 * n_channels; % int16 temp_wh.dat
if mod(file_info.bytes, bytes_per_sample) ~= 0
    error('getPotentialMerges:InvalidTempWhSize', ...
        'temp_wh.dat size is not divisible by 2*n_chan_bin.');
end
n_file_samples = file_info.bytes / bytes_per_sample;
mmap = memmapfile(path_data, ...
    'Format', {'int16', [n_channels, n_file_samples], 'x'});

%% Exclude clusters labelled as noise
cluster_ids = unique(spike_clusters);
cluster_group = readtable(fullfile(folder_data, 'cluster_group.tsv'), ...
    'Delimiter', '\t', 'FileType', 'text');
names = cluster_group.Properties.VariableNames;
id_col = find(strcmpi(names, 'cluster_id'), 1);
group_col = find(strcmpi(names, 'group'), 1);
if isempty(id_col) || isempty(group_col)
    cluster_id_noise = zeros(0, 1);
else
    labels = lower(strtrim(string(cluster_group.(names{group_col}))));
    cluster_id_noise = double(cluster_group.(names{id_col}));
    cluster_id_noise = cluster_id_noise(labels == "noise");
end
cluster_id_non_noise = setdiff(cluster_ids, cluster_id_noise);

fprintf('Computing mean waveforms for %d non-noise clusters...\n', ...
    numel(cluster_id_non_noise));
n_clusters = numel(cluster_id_non_noise);
mean_waveforms = nan(n_clusters, n_samples);
peak_chan_orig = nan(n_clusters, 1);
peak_probe_ind = nan(n_clusters, 1);
n_waveforms_used = zeros(n_clusters, 1);
valid_cluster = false(n_clusters, 1);

% Kilosort 4 multiplies preprocessed data by 200 before writing int16.
temp_wh_scale = 200;

for k = 1:n_clusters
    cluster_id = cluster_id_non_noise(k);
    % Kilosort spike_times are zero-based sample positions. Convert to
    % one-based MATLAB indices before indexing the memory map.
    centers = spike_times(spike_clusters == cluster_id) + 1;
    is_in_file = centers + waveform_window(1) >= 1 & ...
                 centers + waveform_window(2) <= n_file_samples;
    centers = centers(is_in_file);

    if isempty(centers)
        warning('getPotentialMerges:NoValidWaveforms', ...
            'Cluster %g has no waveform fully inside temp_wh.dat; skipping.', ...
            cluster_id);
        continue;
    end

    waveform_sum = zeros(n_active_channels, n_samples);
    for s = 1:numel(centers)
        t0 = centers(s) + waveform_window(1);
        t1 = centers(s) + waveform_window(2);
        % Reorder binary-file channels into Kilosort probe order before
        % applying whitening_mat_inv.
        snippet_whitened = double(mmap.Data.x(channel_rows, t0:t1)) ...
            ./ temp_wh_scale;
        snippet_uv = (whitening_mat_inv * snippet_whitened) * uV_per_bit;
        waveform_sum = waveform_sum + snippet_uv;
    end

    mean_all_channels = waveform_sum / numel(centers);
    peak_to_peak = max(mean_all_channels, [], 2) ...
        - min(mean_all_channels, [], 2);
    [~, peak_idx] = max(peak_to_peak);

    mean_waveforms(k, :) = mean_all_channels(peak_idx, :);
    peak_probe_ind(k) = peak_idx;
    peak_chan_orig(k) = channel_map(peak_idx) + 1;
    n_waveforms_used(k) = numel(centers);
    valid_cluster(k) = true;

    if mod(k, 10) == 0 || k == n_clusters
        fprintf('%d / %d mean waveforms computed.\n', k, n_clusters);
    end
end

%% Characterize each mean waveform once
trough_amplitude = nan(n_clusters, 1);
trough_latency = nan(n_clusters, 1);
zero_crossing_interval = nan(n_clusters, 1);
peak_amplitude = nan(n_clusters, 1);
half_width_interval = nan(n_clusters, 1);

for k = find(valid_cluster).'
    [trough_amplitude(k), trough_latency(k), ...
        zero_crossing_interval(k), peak_amplitude(k), ...
        half_width_interval(k)] = characterizeWaveform(mean_waveforms(k, :));
end

%% Detect potential merges
fprintf('Start detecting potential merges!\n');
merge_pairs = zeros(0, 2);
wcc = [];
if verbose
    figure_folder = fullfile(folder_data, 'Fig', 'PotentialMerges');
    if ~isfolder(figure_folder)
        mkdir(figure_folder);
    end
end

valid_indices = find(valid_cluster);
for a = 1:numel(valid_indices)
    k = valid_indices(a);
    for b = a+1:numel(valid_indices)
        j = valid_indices(b);
        % Only clusters with the same physical peak channel are compared.
        if peak_chan_orig(k) ~= peak_chan_orig(j)
            continue;
        end

        metric_values = [ ...
            abs(trough_amplitude(k) - trough_amplitude(j)), ...
            abs(trough_latency(k) - trough_latency(j)), ...
            abs(zero_crossing_interval(k) - zero_crossing_interval(j)), ...
            abs(peak_amplitude(k) - peak_amplitude(j)), ...
            abs(half_width_interval(k) - half_width_interval(j))];
        wcc_value = waveformCrossCorrelation( ...
            mean_waveforms(k, :), mean_waveforms(j, :));

        is_similar = all(isfinite(metric_values)) && ...
            isfinite(wcc_value) && all(metric_values < thresholds) && ...
            wcc_value > wcc_threshold;
        if ~is_similar
            continue;
        end
        wcc(end+1, :) = wcc_value; %#ok<AGROW>
        merge_pairs(end+1, :) = ...
            [cluster_id_non_noise(k), cluster_id_non_noise(j)]; %#ok<AGROW>
        if verbose
            plotPotentialMerge(figure_folder, ...
                cluster_id_non_noise(k), cluster_id_non_noise(j), ...
                mean_waveforms(k, :), mean_waveforms(j, :), ...
                peak_chan_orig(k), n_waveforms_used(k), ...
                n_waveforms_used(j), metric_values, thresholds, ...
                wcc_value, wcc_threshold, n_samples);
        end
    end

    if mod(a, 10) == 0 || a == numel(valid_indices)
        fprintf('%d / %d non-noise clusters compared.\n', ...
            a, numel(valid_indices));
    end
end

% tbl = table();
% [~, idx] = ismember(merge_pairs(:,1), cluster_id_non_noise);
% tbl.ch_orig = peak_chan_orig(idx);
% tbl.cluster_A = merge_pairs(:, 1);
% tbl.cluster_B = merge_pairs(:, 2);
% writetable(tbl, fullfile(folder_data, 'cluster_merge_pairs.tsv'), ...
%     'Delimiter', '\t', 'FileType', 'text');

fprintf('Found %d potential merges!\n', size(merge_pairs, 1));
end
