function wcc = waveformCrossCorrelation(waveform_a, waveform_b)
%WAVEFORMCROSSCORRELATION Calculate zero-lag normalized waveform correlation.
%
% WCC is the normalized dot product after subtracting each waveform's
% mean. It is equivalent to the Pearson correlation coefficient and does
% not require the Signal Processing Toolbox.

waveform_a = double(waveform_a(:));
waveform_b = double(waveform_b(:));
if numel(waveform_a) ~= numel(waveform_b)
    error('waveformCrossCorrelation:SizeMismatch', ...
        'The two waveforms must have the same number of samples.');
end

valid = isfinite(waveform_a) & isfinite(waveform_b);
waveform_a = waveform_a(valid);
waveform_b = waveform_b(valid);
if numel(waveform_a) < 2
    wcc = NaN;
    return;
end

waveform_a = waveform_a - mean(waveform_a);
waveform_b = waveform_b - mean(waveform_b);
denominator = norm(waveform_a) * norm(waveform_b);
if denominator <= eps
    wcc = NaN;
else
    wcc = dot(waveform_a, waveform_b) / denominator;
    wcc = max(-1, min(1, wcc));
end
end
