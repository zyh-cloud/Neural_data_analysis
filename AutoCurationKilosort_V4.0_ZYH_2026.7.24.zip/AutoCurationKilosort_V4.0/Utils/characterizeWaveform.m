function [trough_amp, trough_lat, zci, peak_amp, hwi] = ...
        characterizeWaveform(waveform)
%CHARACTERIZEWAVEFORM Extract waveform morphology metrics.
%
% Outputs:
%   trough_amp - trough amplitude (uV)
%   trough_lat - trough latency (samples)
%   zci        - interval between zero crossings flanking the trough
%   peak_amp   - largest positive value at or after the trough (uV)
%   hwi        - interval between crossings at half trough amplitude (samples)

waveform = double(waveform(:).');

[trough_amp, trough_lat] = min(waveform);
peak_amp = max(waveform(trough_lat:end));

% Zero crossings flanking the trough.
left_crossings = zeros(0, 1);
right_crossings = zeros(0, 1);
for i = 1:numel(waveform)-1
    y1 = waveform(i);
    y2 = waveform(i+1);
    if ~isfinite(y1) || ~isfinite(y2) || y1 == y2
        continue;
    end

    if y1 >= 0 && y2 < 0
        left_crossings(end+1, 1) = i - y1 / (y2 - y1); %#ok<AGROW>
    end
    if y1 < 0 && y2 >= 0
        right_crossings(end+1, 1) = i - y1 / (y2 - y1); %#ok<AGROW>
    end
end

left_crossings = left_crossings(left_crossings < trough_lat);
right_crossings = right_crossings(right_crossings > trough_lat);
if isempty(left_crossings) || isempty(right_crossings)
    zci = NaN;
else
    zci = right_crossings(1) - left_crossings(end);
end

% Half-width interval (HWI): crossings at half of the negative trough.
hwi = NaN;
if trough_amp < 0
    half_level = trough_amp / 2;
    left_half_crossings = zeros(0, 1);
    right_half_crossings = zeros(0, 1);

    for i = 1:numel(waveform)-1
        y1 = waveform(i);
        y2 = waveform(i+1);
        if y1 == y2
            continue;
        end

        crossing = i + (half_level - y1) / (y2 - y1);
        if y1 >= half_level && y2 < half_level && crossing < trough_lat
            left_half_crossings(end+1, 1) = crossing; %#ok<AGROW>
        end
        if y1 < half_level && y2 >= half_level && crossing > trough_lat
            right_half_crossings(end+1, 1) = crossing; %#ok<AGROW>
        end
    end

    if ~isempty(left_half_crossings) && ~isempty(right_half_crossings)
        hwi = right_half_crossings(1) - left_half_crossings(end);
    end
end
end
