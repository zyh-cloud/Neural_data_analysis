function removeNoiseInsideCluster_zyh(folder_data, userSettings)
% REMOVENOISEINSIDECLUSTER remove the "noise" in the cluster
%
% Determination of noise: outliers in the feature space. Utilize MATLAB
% isoutlier() function and PC features from Kilosort output to determine noise.
%
% Input (required):
%   - folder_data: the folder where the data is located
%   - userSettings: the global settings
%
% Input (name-value pairs):
%   - verbose: false (default)
%       true / false. Control whether to generate figure output.
%   - n_pc_feature: 2 (default).
%       Number of PC features to use. Range from 1 to 3.
%   - n_random_spikes: 100 (default)
%       The number of spikes to load from temp_wh.dat to compute the mean of the waveforms
%       and determine the channel with the largest amplitude.
%       It will be slow if the number is high.
%   - threshold: 5 (default)
%       The threshold used to determine the outlier in function isoutlier().
%       The code is `isoutlier(pc_features, 'median', 'ThresholdFactor', threshold)`;

% ======================新增开始==========================================================
%   - amp_thres_uv: 600 (default)
%       峰值通道任意spike任意采样点的电压绝对值超过该值则判定为噪声，单位μV
%   - uV_per_bit: 0.25 (default)
%       原始int16 AD值转微伏的转换系数，默认适配Blackrock系统
%======================新增结束==========================================================

% Output:
%   The outlier spikes will be spilted as new clusters and labeled as 'noise'.
%   The corresponding files will be updated as phy does.
%

% parameters
n_pc_feature = userSettings.removeNoiseInsideCluster.n_pc_feature;
n_random_spikes = userSettings.removeNoiseInsideCluster.n_random_spikes;
threshold = userSettings.removeNoiseInsideCluster.threshold;
verbose = userSettings.removeNoiseInsideCluster.verbose;
waveform_window = userSettings.removeNoiseInsideCluster.waveform_window;

% ====================== 新增开始 ======================
% 读取幅值阈值与AD转换系数
amp_thres_uv = userSettings.removeNoiseInsideCluster.amp_thres_uv;
uV_per_bit = userSettings.removeNoiseInsideCluster.uV_per_bit;
% ====================== 新增结束 ======================

path_data = getKilosortTempWhPath(folder_data);
spike_clusters = readNPY(fullfile(folder_data, 'spike_clusters.npy'));
spike_times = readNPY(fullfile(folder_data, 'spike_times.npy'));
spike_templates = readNPY(fullfile(folder_data, 'spike_templates.npy'));
pc_features = readNPY(fullfile(folder_data, 'pc_features.npy'));
pc_feature_ind = readNPY(fullfile(folder_data, 'pc_feature_ind.npy'));
n_channels = getKilosortNChannels(folder_data);
templates = readNPY(fullfile(folder_data, 'templates.npy'));

chan_map = readNPY(fullfile(folder_data, 'channel_map.npy'));

% ====================== 新增开始 ======================
% 读取逆白化矩阵，用于将白化数据还原为原始AD尺度
% whitening_mat_inv 维度: [n_channels, n_channels]
whitening_mat_inv = readNPY(fullfile(folder_data, 'whitening_mat_inv.npy'));
gain = 200;
% ====================== 新增结束 ======================

% Get the IDs of non-noise clusters
cluster_group = readtable(fullfile(folder_data, 'cluster_group.tsv'), 'Delimiter', '\t', 'FileType', 'text');
if any(strcmpi(cluster_group.Properties.VariableNames, 'group'))
    cluster_noise = cluster_group.cluster_id(strcmpi(cluster_group.group, 'noise'));
else
    cluster_noise = [];
end

cluster_ids = unique(spike_clusters);
cluster_non_noise = setdiff(cluster_ids, cluster_noise);

% Clean the waveforms in non-noise clusters
disp('Start detecting the noise inside clusters!');
dir_output = dir(path_data);
nFileSamp = dir_output.bytes ./ 2 ./ n_channels;
mmap = memmapfile(path_data, 'Format', {'int16', [n_channels, nFileSamp], 'x'});
id_noise = [];

for k = 1:length(cluster_non_noise)
    id = cluster_non_noise(k);
    spike_ids = find(spike_clusters == id);
    spike_times_this = spike_times(spike_ids);

    n_waveforms = min(length(spike_times_this), n_random_spikes);
    idx_rand = randperm(length(spike_times_this), n_waveforms);
    waveforms = zeros(n_waveforms, n_channels, diff(waveform_window)+1);

    idx_remove = [];
    for j = 1:n_waveforms
        t0 = spike_times_this(idx_rand(j)) + 1 + waveform_window(1);
        t1 = spike_times_this(idx_rand(j)) + 1 + waveform_window(2);
        if t0 < 1 || t1 > size(mmap.Data.x, 2)
            idx_remove = [idx_remove, j];
            continue
        end

        waveforms(j,:,:) = mmap.Data.x(:, t0:t1);
    end
    waveforms(idx_remove,:,:) = [];
    
    % mean_waveforms = squeeze(mean(waveforms, 1)); % 383 x 64
    % [~, ch_largest] = max(max(mean_waveforms,[],2) - min(mean_waveforms,[],2));
    % ch_largest_ind0 = ch_largest-1;

    %======================================================================
    temp_wave = squeeze(templates(id+1, :, :));   % nt × n_chan
    wave_L2 = vecnorm(temp_wave, 2, 1);           % 每个通道波形L2范数
    [~, ch_largest] = max(wave_L2);               % ch_largest在数值上完全等价于 1-based 的电极物理触点号
    ch_largest_ind0 = ch_largest - 1;             % 转回KS0起始通道索引i

    %======================================================================

    % detect outliers
    is_outliers = false(1, length(spike_times_this));

    % load the pc features of the ch_largest
    pc_features_cluster = pc_features(spike_ids, :, :);
    pc_features_this = zeros(length(spike_times_this), n_pc_feature);
    spike_templates_this = spike_templates(spike_ids);
    for j = 1:length(spike_times_this)
        template_id_ind0 = spike_templates_this(j);
        ch = pc_feature_ind(template_id_ind0+1, :);
        idx = find(ch == ch_largest_ind0);
        if isempty(idx)
            is_outliers(j) = 1;
            pc_features_this(j,:) = NaN;
            continue
        end

        pc_features_this(j,:) = squeeze(pc_features_cluster(j, 1:n_pc_feature, idx));
    end

    for j = 1:n_pc_feature
        idx_found = isoutlier(pc_features_this(:,j), 'median', 'ThresholdFactor', threshold);
        is_outliers(idx_found) = 1;
    end

    % ====================== 新增：幅值阈值检测 ======================
    % 在当前Unit的峰值通道上计算每个spike的任意采样点电压绝对值，超过阈值则标记为噪声
    % 与PC离群点为「逻辑或」关系，满足任一即判定为簇内噪声
    n_spikes_this = length(spike_times_this);

    for j = 1:n_spikes_this
        % 已被PC判定为离群点的跳过，减少重复计算
        if is_outliers(j)
            continue;
        end

        t0 = spike_times_this(j) + 1 + waveform_window(1);
        t1 = spike_times_this(j) + 1 + waveform_window(2);
        % 数据边界外的spike直接标记为异常
        if t0 < 1 || t1 > size(mmap.Data.x, 2)
            is_outliers(j) = 1;
            continue;
        end

        % 1. 提取所有通道的白化波形 [n_channels, n_timepoints]
        %    注意：必须取全通道白化数据，才能通过逆白化还原单通道原始信号
        wave_whitened = double(mmap.Data.x(chan_map+1, t0:t1));
        wave_whitened = wave_whitened / gain;
        % 2. 逆白化变换：还原到原始AD信号空间
        % 单通道逆白化：取逆白化矩阵中峰值通道对应的行，点乘白化波形
        wave_raw = whitening_mat_inv(ch_largest, :) * wave_whitened;

        % 3. 计算峰值通道波形的电压绝对值最大值，转换为μV
        max_abs_uv = max(abs(wave_raw)) * uV_per_bit;

        if max_abs_uv > amp_thres_uv
            is_outliers(j) = 1;
        end
    end
    % ====================== 新增结束 ======================


    % if all(is_outliers == 0)  || all(is_outliers == 1) % 修改了
    %     continue
    % end

    % ====================== 新增全噪声簇直接标记noise逻辑 ======================
    if all(is_outliers == 0)
        % 无异常spike，直接跳过
        continue;

    elseif all(is_outliers == 1)
        % 整簇全部判定为噪声，直接修改cluster_group.tsv标记为noise，不拆分
        fprintf('cluster %d 全部spike判定为噪声，直接将该簇标记为noise，跳过拆分\n', id);
        id_noise(end+1) = id;
        continue;

    else
        % ==========================================================================

        % plot the outliers
        if verbose
            % extract the waveforms of outliers
            n_outliers = sum(is_outliers);
            idx_outlier = find(is_outliers);

            waveforms_outliers = zeros(n_outliers, n_channels, diff(waveform_window)+1);
            idx_remove = [];
            for j = 1:n_outliers
                t0 = spike_times_this(idx_outlier(j)) + 1 + waveform_window(1);
                t1 = spike_times_this(idx_outlier(j)) + 1 + waveform_window(2);
                if t0 < 1 || t1 > size(mmap.Data.x, 2)
                    idx_remove = [idx_remove, j];
                    continue
                end

                waveforms_outliers(j,:,:) = mmap.Data.x(:, t0:t1);
            end
            waveforms_outliers(idx_remove,:,:) = [];

            if ~isempty(waveforms_outliers)
                fig = EasyPlot.figure();
                ax_waveform = EasyPlot.axes(fig,...
                    'Width', 6,...
                    'Height', 6,...
                    'XAxisVisible', 'off',...
                    'YAxisVisible', 'off');
                ax_feature = EasyPlot.createAxesAgainstAxes(fig, ax_waveform, 'right',...
                    'MarginBottom', 1,...
                    'MarginLeft', 1);


                plot(ax_waveform, 1:diff(waveform_window)+1, squeeze(waveforms(:,ch_largest,:)), 'k-');
                plot(ax_waveform, 1:diff(waveform_window)+1, squeeze(waveforms_outliers(:,ch_largest,:)), 'r-');
                title(ax_waveform, ['Outliers: ', num2str(n_outliers), '/', num2str(length(spike_times_this))]);

                plot(ax_feature, pc_features_this(:,1), pc_features_this(:,2), 'k.');
                plot(ax_feature, pc_features_this(idx_outlier,1), pc_features_this(idx_outlier,2), 'r.');
                xlabel(ax_feature, 'PC1');
                ylabel(ax_feature, 'PC2');
                EasyPlot.cropFigure(fig);
                title(ax_feature, ['Cluster ', num2str(id)]);

                output_folder = fullfile(folder_data, 'Fig/RemoveWaveforms/');
                if ~exist(output_folder, 'dir')
                    mkdir(output_folder);
                end
                output_filename = ['Cluster', num2str(id)];
                EasyPlot.exportFigure(fig, fullfile(output_folder, output_filename));
                close all;
            end
        end

        % remove the outliers
        removeSpikes(folder_data, id, spike_ids(is_outliers));
        fprintf('Removed %d / %d spikes in cluster %d!\n', sum(is_outliers), length(spike_ids), id);

        if mod(k, 100) == 1
            fprintf('%d / %d done!\n', k, length(cluster_non_noise));
        end
    end
end

% read the old cluster groups
cluster_group = readtable(fullfile(folder_data, 'cluster_group.tsv'), 'Delimiter', '\t', 'FileType', 'text');

if any(strcmpi(cluster_group.Properties.VariableNames, 'group'))
    cluster_id_old = cluster_group.cluster_id;
    group_old = cluster_group.group;
end

cluster_id_new = cluster_id_old;
group_new      = group_old;

for ii = 1:length(id_noise)
    nn = id_noise(ii);

    % remove the cluster_id that will be updated
    idx_kept = arrayfun(@(id) ~any(nn == id), cluster_id_new);
    cluster_id_new = cluster_id_new(idx_kept);
    group_new = group_new(idx_kept);

    % append
    cluster_id_new(end+1) = nn;
    group_new(end+1) = {"noise"};
end

% remove the unsorted labels
idx_unsorted = find(strcmpi(group_new, 'unsorted'));
cluster_id_new(idx_unsorted) = [];
group_new(idx_unsorted) = [];

% save to cluster_group.tsv
tbl = table();
tbl.cluster_id = cluster_id_new;
tbl.group = group_new;

writetable(tbl, fullfile(folder_data, 'cluster_group.tsv'), 'Delimiter', '\t', 'FileType', 'text');

end


