function merge_history = applyPotentialMerges(folder_data, userSettings)
%APPLYPOTENTIALMERGES Iteratively merge Kilosort4 clusters in batches.
%
%   MERGE_HISTORY = applyPotentialMerges(FOLDER_DATA, USERSETTINGS)
%
% Each iteration:
%   1. Recalculates candidates from the current spike_clusters.npy by
%      calling getPotentialMerge.
%   2. Sorts candidates by descending WCC.
%   3. Greedily selects every valid non-overlapping pair.
%   4. Applies the entire selected batch.
%   5. Recalculates candidates for the next iteration.
%
% There is no one-pair-per-iteration mode or maximum batch size. A cluster
% can occur in at most one selected pair in a batch because all scores in
% that batch were calculated before any of its merges were applied.
%
% Successful merges are written immediately to cluster_merge_history.tsv.

    narginchk(2, 2);

    folder_data = char(folder_data);

    spike_clusters_file = fullfile(folder_data, 'spike_clusters.npy');

    history_file = fullfile(folder_data, 'cluster_merge_history.tsv');
    merge_history = emptyMergeHistory();
    iteration = 0;

    while true
        iteration = iteration + 1;
        fprintf('\n========== Merge iteration %d ==========\n', iteration);

        % Candidates always reflect the current clustering state.
        [merge_pairs, wcc] = getPotentialMerge( ...
            folder_data, userSettings);
        [merge_pairs, wcc] = validateCandidates(merge_pairs, wcc);

        if isempty(merge_pairs)
            fprintf('No potential merges remain.\n');
            break
        end

        spike_clusters = readNPY(spike_clusters_file);
        active_cluster_ids = unique(double(spike_clusters(:)));
        [selected_pairs, selected_wcc, selected_rank] = ...
            selectBatch(merge_pairs, wcc, active_cluster_ids);

        if isempty(selected_pairs)
            fprintf('No valid non-overlapping pairs remain.\n');
            break
        end

        fprintf('Selected %d non-overlapping pairs for this batch.\n', ...
            size(selected_pairs, 1));

        successful_merges = 0;
        for pair_index = 1:size(selected_pairs, 1)
            cluster_ids = selected_pairs(pair_index, :);
            fprintf('Merging cluster %d and %d, WCC = %.4f...\n', ...
                cluster_ids(1), cluster_ids(2), ...
                selected_wcc(pair_index));

            try
                id_new = mergeCluster(folder_data, cluster_ids);
            catch exception
                % Preserve completed work before reporting a failed merge.
                writeHistory(merge_history, history_file);
                failure = MException( ...
                    'applyPotentialMerges:MergeFailed', ...
                    'Failed to merge clusters %d and %d: %s', ...
                    cluster_ids(1), cluster_ids(2), exception.message);
                failure = addCause(failure, exception);
                throw(failure)
            end

            validateattributes(id_new, {'numeric'}, ...
                {'scalar', 'real', 'finite'}, ...
                mfilename, 'id_new');
            new_row = table( ...
                iteration, ...
                selected_rank(pair_index), ...
                cluster_ids(1), ...
                cluster_ids(2), ...
                double(id_new), ...
                selected_wcc(pair_index), ...
                'VariableNames', merge_history.Properties.VariableNames);
            merge_history = [merge_history; new_row]; %#ok<AGROW>
            successful_merges = successful_merges + 1;

            % Save after each successful merge so partial progress survives.
            writeHistory(merge_history, history_file);
        end

        if successful_merges == 0
            warning('applyPotentialMerges:NoProgress', ...
                'The batch produced no successful merge; stopping.');
            break
        end
    end

    writeHistory(merge_history, history_file);
    fprintf('\nMerge process finished.\n');
    fprintf('Total merges: %d\n', height(merge_history));
    fprintf('History saved to:\n%s\n', history_file);
end

function history = emptyMergeHistory()
    history = table( ...
        zeros(0, 1), ...
        zeros(0, 1), ...
        zeros(0, 1), ...
        zeros(0, 1), ...
        zeros(0, 1), ...
        zeros(0, 1), ...
        'VariableNames', { ...
        'iteration', ...
        'candidate_rank', ...
        'cluster_A', ...
        'cluster_B', ...
        'cluster_new', ...
        'WCC'});
end

function [merge_pairs, wcc] = validateCandidates(merge_pairs, wcc)
    if isempty(merge_pairs)
        merge_pairs = zeros(0, 2);
        wcc = zeros(0, 1);
        return
    end

    if ~isnumeric(merge_pairs) || ~isreal(merge_pairs) || ...
            size(merge_pairs, 2) ~= 2
        error('applyPotentialMerges:InvalidMergePairs', ...
            'merge_pairs must be a real numeric N-by-2 matrix.');
    end

    merge_pairs = double(merge_pairs);
    wcc = double(wcc(:));
    if numel(wcc) ~= size(merge_pairs, 1)
        error('applyPotentialMerges:WCCSizeMismatch', ...
            'The number of WCC values must equal the number of pairs.');
    end
end

function [selected_pairs, selected_wcc, selected_rank] = ...
        selectBatch(merge_pairs, wcc, active_cluster_ids)
    valid = isfinite(wcc) & ...
        all(isfinite(merge_pairs), 2) & ...
        all(merge_pairs == fix(merge_pairs), 2) & ...
        merge_pairs(:, 1) ~= merge_pairs(:, 2);
    candidate_rows = find(valid);

    if isempty(candidate_rows)
        selected_pairs = zeros(0, 2);
        selected_wcc = zeros(0, 1);
        selected_rank = zeros(0, 1);
        return
    end

    % Normalize pair orientation and use cluster IDs as deterministic
    % tie-breakers when WCC values are equal.
    normalized_pairs = sort(merge_pairs(candidate_rows, :), 2);
    sort_keys = [-wcc(candidate_rows), normalized_pairs, candidate_rows];
    [~, order] = sortrows(sort_keys, 1:size(sort_keys, 2));
    sorted_rows = candidate_rows(order);
    sorted_pairs = normalized_pairs(order, :);

    candidate_count = numel(sorted_rows);
    selected_pairs = zeros(candidate_count, 2);
    selected_wcc = zeros(candidate_count, 1);
    selected_rank = zeros(candidate_count, 1);
    used_cluster_ids = zeros(2 * candidate_count, 1);
    used_count = 0;
    selected_count = 0;

    for rank = 1:candidate_count
        pair = sorted_pairs(rank, :);
        if ~all(ismember(pair, active_cluster_ids))
            continue
        end
        if any(ismember(pair, used_cluster_ids(1:used_count)))
            continue
        end

        selected_count = selected_count + 1;
        selected_pairs(selected_count, :) = pair;
        selected_wcc(selected_count) = wcc(sorted_rows(rank));
        selected_rank(selected_count) = rank;
        used_cluster_ids(used_count + (1:2)) = pair(:);
        used_count = used_count + 2;
    end

    selected_pairs = selected_pairs(1:selected_count, :);
    selected_wcc = selected_wcc(1:selected_count);
    selected_rank = selected_rank(1:selected_count);
end

function writeHistory(merge_history, history_file)
    writetable(merge_history, history_file, ...
        'Delimiter', '\t', 'FileType', 'text');
end
