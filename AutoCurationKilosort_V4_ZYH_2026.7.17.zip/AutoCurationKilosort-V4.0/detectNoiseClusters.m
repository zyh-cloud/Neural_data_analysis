function detectNoiseClusters(folder_data, userSettings)
% DETECTNOISECLUSTERS detect and remove the clusters which are pure noise
%
% Input:
%   - folder_data: the folder where the data is located
%   - userSettings: the global settings
%
% Output:
%   The dectected noise clusters will be labeled as "noise" in cluster_group.tsv
%
% Determination of noise:
%   (1) Firing rate < 0.05 Hz
%   (2) Signal-to-noise ratio > 3
%

% load the params
min_firing_rate = userSettings.detectNoiseClusters.min_firing_rate;
min_signal_to_noise_ratio = userSettings.detectNoiseClusters.min_signal_to_noise_ratio;
n_random_spikes = userSettings.detectNoiseClusters.n_random_spikes;
waveform_window = userSettings.detectNoiseClusters.waveform_window;
baseline_window = userSettings.detectNoiseClusters.baseline_window - waveform_window(1) + 1;

% load the data
path_data = getKilosortTempWhPath(folder_data);
spike_clusters = readNPY(fullfile(folder_data, 'spike_clusters.npy'));
spike_times = readNPY(fullfile(folder_data, 'spike_times.npy'));
n_channels = getKilosortNChannels(folder_data);
templates = readNPY(fullfile(folder_data, 'templates.npy'));

dir_output = dir(path_data);
nFileSamp = dir_output.bytes ./ 2 ./ n_channels;
mmap = memmapfile(path_data, 'Format', {'int16', [n_channels, nFileSamp], 'x'});

% detect noise
disp('Start detecting noise clusters');
duration_sec = double(max(spike_times) - min(spike_times))./30000;

cluster_ids = unique(spike_clusters);
idx_noise = [];
%==========================================================================开始
n_cluster = length(cluster_ids);
cluster_group = readtable(fullfile(folder_data, 'cluster_KSLabel.tsv'), 'Delimiter', '\t', 'FileType', 'text');
labels = cell(n_cluster, 1);
if any(strcmpi(cluster_group.Properties.VariableNames, 'cluster_id'))
    for k = 1:n_cluster
        idx = find(cluster_group.cluster_id == cluster_ids(k));
        if isempty(idx)
            continue
        end

        labels{k} = cluster_group.KSLabel{idx};
    end
end

% noise cluster label curation
cluster_noise = readtable(fullfile(folder_data, 'cluster_group.tsv'), 'Delimiter', '\t', 'FileType', 'text');
if any(strcmpi(cluster_noise.Properties.VariableNames, 'cluster_id'))
    for k = 1:size(cluster_noise,1)
        idx = find(cluster_group.cluster_id == cluster_noise.cluster_id(k));
        if isempty(idx)
            continue
        end

        labels{idx} = cluster_noise.group{k};
    end
end

% save to cluster_KSLabel.tsv
tbl = table();
tbl.cluster_id = cluster_group.cluster_id;
tbl.KSLabel = labels;

writetable(tbl, fullfile(folder_data, 'cluster_KSLabel.tsv'), 'Delimiter', '\t', 'FileType', 'text');



FR = NaN(n_cluster, 1);
SNR = NaN(n_cluster, 1);

%==========================================================================结束
for k = 1:n_cluster
%==========================================================================开始
    if strcmpi(labels{k}, 'noise')
        if mod(k, 10) == 1
            fprintf('%d / %d done!\n', k, n_cluster);
        end
        continue
    end
%==========================================================================结束
    id = cluster_ids(k);
    spike_ids = find(spike_clusters == id);

    FR(k) = length(spike_ids)./duration_sec;
    if FR(k) < min_firing_rate
        idx_noise = [idx_noise, id];
        fprintf('[FR = %.2f] Cluster %d is putative noise!\n', FR(k), id);

        if mod(k, 50) == 1
            fprintf('%d / %d done!\n', k, length(cluster_ids));
        end
        continue
    end

    spike_times_this = spike_times(spike_ids);

    n_waveforms = min(length(spike_times_this), n_random_spikes);
    idx_rand = randperm(length(spike_times_this), n_waveforms);
    waveforms = zeros(n_waveforms, n_channels, diff(waveform_window)+1);
    
    idx_remove = [];
    for j = 1:n_waveforms
        t0 = spike_times_this(idx_rand(j)) + waveform_window(1);
        t1 = spike_times_this(idx_rand(j)) + waveform_window(2);
        if t0 < 1 || t1 > size(mmap.Data.x, 2)
            idx_remove = [idx_remove, j];
            continue
        end
        waveforms(j,:,:) = mmap.Data.x(:, t0:t1);
    end
    waveforms(idx_remove,:,:) = [];
    
    mean_waveforms = squeeze(mean(waveforms, 1)); % 383 x 64
    [amplitude, ch_largest] = max(max(mean_waveforms,[],2) - min(mean_waveforms,[],2));
    % temp_wave = squeeze(templates(id+1, :, :));   % nt × n_chan
    % wave_L2 = vecnorm(temp_wave, 2, 1);           % 每个通道波形L2范数
    % [~, ch_largest] = max(wave_L2);               % ch_largest在数值上完全等价于 1-based 的电极物理触点号
    % mean_waveforms = squeeze(mean(waveforms, 1));
    % amplitude = max(mean_waveforms(ch_largest, :))-min(mean_waveforms(ch_largest, :));

    baselines = waveforms(:, ch_largest, baseline_window(1):baseline_window(2));
    variance_baseline = mean(baselines(:).^2);

    SNR(k) = amplitude.^2./variance_baseline;

    if SNR(k) < min_signal_to_noise_ratio
        fprintf('[SNR = %.2f] Cluster %d is putative noise!\n', SNR(k), id);
        idx_noise = [idx_noise, id];

        if mod(k, 50) == 1
            fprintf('%d / %d done!\n', k, length(cluster_ids));
        end
        continue
    end
    
    if mod(k, 50) == 1
        fprintf('%d / %d done!\n', k, length(cluster_ids));
    end
end

filepath = fullfile(folder_data, 'FR_SNR_cluster.mat');
save(filepath, 'FR', 'SNR', 'cluster_ids', 'labels', 'idx_noise');

% remove the noise clusters
fprintf('Found %d / %d noise clusters!\n', length(idx_noise), length(cluster_ids));
labelKilosort(folder_data, idx_noise, 'noise');

end
